extends CharacterBody2D

@export var speed =150;
@export var gra=2000;
var direction;
@export var acc=1000;
@export var dcc=2000;
@export var jump=-700;
@export var jumpbuffer=0.2;
var jumpbuffercount=0;
@onready var animation= $AnimatedSprite2D


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y+=gra*delta;
		
	if velocity.x==0 and is_on_floor() and !Input.is_action_pressed("ui_down"):
		animation.play("ashokaidle");
	elif velocity.x!=0 and is_on_floor():
		animation.play("ashokarun");
	elif velocity.y<0:
		animation.play("ashokajump");
	elif velocity.y>0:
		animation.play("ashokajump")						
	
	direction=Input.get_axis("ui_left","ui_right");
	
	if direction!=0:
		velocity.x=move_toward(velocity.x,speed*direction,acc*delta);
	else:
		velocity.x=move_toward(velocity.x,0,dcc*delta);			
		
		
	if direction==1:
		$AnimatedSprite2D.flip_h=false;
	if direction==-1:
		$AnimatedSprite2D.flip_h=true;
		
	if Input.is_action_just_pressed("ui_up"):
		jumpbuffercount=jumpbuffer;
	jumpbuffercount-=delta;		
	if jumpbuffercount>0 and is_on_floor():
		velocity.y=jump;
		jumpbuffercount=0;	
	if !Input.is_action_pressed("ui_up") and velocity.y<0:
		velocity.y*=0.5;	
	if Input.is_action_just_pressed("ui_down"):
		animation.play("ashokaattack")
			
			
	move_and_slide();

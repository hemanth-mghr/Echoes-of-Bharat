extends CharacterBody2D


const SPEED = 200.0
const gravity = 200

@export var max_health: int = 100
var health: int = 100
var invulnerable: bool = false
var blink_time: float = 0.0
var blink_interval: float = 0.0
var blink_visible: bool = true
var is_dead: bool = false

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var health_bar: ProgressBar = $HealthUI/HealthBar


var direction = 0
var move
var playerjump
var jumpreleased


func _ready() -> void:
	health = max_health
	add_to_group("player")
	health_bar.max_value = max_health
	health_bar.value = health


func take_damage(amount: int = 30) -> void:
	if invulnerable or is_dead:
		return
	health = maxi(health - amount, 0)
	health_bar.value = health
	if health == 0:
		die()
	else:
		start_hit_blink()


func die() -> void:
	is_dead = true
	invulnerable = false
	velocity = Vector2.ZERO
	move = false
	sprite.visible = true
	sprite.modulate = Color(0.45, 0.45, 0.45, 1.0)
	$CollisionShape2D.set_deferred("disabled", true)
	$attackbox/CollisionShape2D.set_deferred("disabled", true)
	$StateMachine.set_physics_process(false)


func _on_attackbox_body_entered(body: Node2D) -> void:
	if body.is_in_group("enemy") and body.has_method("take_damage"):
		body.take_damage(20)


func start_hit_blink() -> void:
	invulnerable = true
	blink_time = 0.45
	blink_interval = 0.0
	blink_visible = true


func _process(delta: float) -> void:
	if not invulnerable or is_dead:
		return
	blink_time -= delta
	blink_interval -= delta
	if blink_interval <= 0.0:
		blink_visible = not blink_visible
		sprite.visible = blink_visible
		blink_interval = 0.07
	if blink_time <= 0.0:
		invulnerable = false
		sprite.visible = true


func _physics_process(delta: float) -> void:
	if is_dead:
		return
	direction = Input.get_axis("left", "right")

	velocity.y += 2000 * delta


	if move:
		velocity.x = direction * SPEED


	move_and_slide()

class_name Run
extends State


var direction = 0


func enter():
	print("run enter")

	animation.play("run")

	player.move = true


func update(delta):

	direction = Input.get_axis("left", "right")


	if Input.is_action_pressed("right"):
		animation.flip_h = false


	if Input.is_action_pressed("left"):
		animation.flip_h = true


	if not (Input.is_action_pressed("left") or Input.is_action_pressed("right")):
		state_machine.changestate(state_machine.idle)


	if Input.is_action_just_pressed("jump"):
		state_machine.changestate(state_machine.jump)


	if Input.is_action_just_pressed("attack"):
		state_machine.changestate(state_machine.attack)


func exit():
	player.move = false

	print("run exit")

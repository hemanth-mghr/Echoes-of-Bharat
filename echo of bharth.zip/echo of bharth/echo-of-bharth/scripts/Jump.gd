class_name Jump
extends State


const JUMP_VELOCITY = -700.0
const GRAVITY = 1800.0
const FALL_GRAVITY = 3000.0
const JUMP_BUFFER_TIME = 0.12


var jumptime = 0


func enter():

	player.move = true

	jumptime = JUMP_BUFFER_TIME

	print("jump")

	animation.play("jump")


	if jumptime > 0:
		player.velocity.y = JUMP_VELOCITY
		jumptime = 0


func update(delta):

	jumptime -= delta


	print(jumptime)


	if Input.is_action_pressed("left"):
		animation.flip_h = true


	if Input.is_action_pressed("right"):
		animation.flip_h = false


	if Input.is_action_just_pressed("attack"):
		state_machine.changestate(state_machine.attack)


	if player.is_on_floor() and jumptime < 0:

		if Input.is_action_pressed("left") or Input.is_action_pressed("right"):

			state_machine.changestate(state_machine.run)

		else:

			state_machine.changestate(state_machine.idle)


func exit():

	player.move = false

	print("jump exit")

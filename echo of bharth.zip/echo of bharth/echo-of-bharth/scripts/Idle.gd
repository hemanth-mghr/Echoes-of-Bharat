class_name Idle
extends State


func enter():
	print("idle enter")
	animation.play("idle")


func update(delta):

	if Input.is_action_pressed("left") or Input.is_action_pressed("right"):
		state_machine.changestate(state_machine.run)
		print(player.velocity.x)


	if Input.is_action_just_pressed("jump"):
		state_machine.changestate(state_machine.jump)


	if Input.is_action_just_pressed("attack"):
		state_machine.changestate(state_machine.attack)


func exit():
	print("idle exit")

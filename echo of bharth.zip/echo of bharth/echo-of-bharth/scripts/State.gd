class_name State
extends Node


var player
var state_machine
var animation
var animation_player
var attack_box


func enter():
	pass


func update(delta):
	pass


func exit():
	pass

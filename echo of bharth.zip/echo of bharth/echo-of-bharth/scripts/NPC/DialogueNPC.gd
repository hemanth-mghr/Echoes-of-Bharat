class_name DialogueNPC
extends Node2D

@export var target_enemy: Enemy

const DIALOGUE_LINE := "Commander, the enemy ahead is preparing for battle."
const CHOICES: Array[String] = [
	"I will face him as he is.",
	"Give him no chance. Strengthen his defenses."
]

@onready var dialogue_ui: DialogueUI = $DialogueUI

var nearby_player: CharacterBody2D
var paused_player: CharacterBody2D
var player_was_moving: bool = false
var dialogue_open: bool = false


func _ready() -> void:
	$InteractionArea.body_entered.connect(_on_interaction_area_body_entered)
	$InteractionArea.body_exited.connect(_on_interaction_area_body_exited)
	dialogue_ui.choice_selected.connect(_on_choice_selected)


func _process(_delta: float) -> void:
	if dialogue_open or not is_instance_valid(nearby_player):
		return
	if Input.is_action_just_pressed("interact"):
		_begin_dialogue()


func _begin_dialogue() -> void:
	paused_player = nearby_player
	player_was_moving = bool(paused_player.get("move"))
	paused_player.set("move", false)
	paused_player.set_physics_process(false)
	var state_machine := paused_player.get_node_or_null("StateMachine")
	if state_machine:
		state_machine.set_physics_process(false)
	dialogue_open = true
	dialogue_ui.open_dialogue("Commander", DIALOGUE_LINE, CHOICES)


func _on_choice_selected(choice_index: int) -> void:
	if choice_index == 1 and is_instance_valid(target_enemy):
		target_enemy.strengthen()
	dialogue_ui.close_dialogue()
	_resume_player()


func _resume_player() -> void:
	if is_instance_valid(paused_player):
		paused_player.set("move", player_was_moving)
		paused_player.set_physics_process(true)
		var state_machine := paused_player.get_node_or_null("StateMachine")
		if state_machine:
			state_machine.set_physics_process(true)
	paused_player = null
	dialogue_open = false


func _on_interaction_area_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		nearby_player = body as CharacterBody2D
		$InteractionPrompt.show()


func _on_interaction_area_body_exited(body: Node2D) -> void:
	if body == nearby_player and not dialogue_open:
		nearby_player = null
		$InteractionPrompt.hide()

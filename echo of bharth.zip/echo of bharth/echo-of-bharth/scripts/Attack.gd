class_name Attack
extends State


var hitbox_shape
var original_hitbox_x = 0.0
var original_position_saved = false


func enter():
	print("attack enter")

	# Get the actual CollisionShape2D
	hitbox_shape = attack_box.get_node("CollisionShape2D")


	# Save the original position from the scene
	if not original_position_saved:
		original_hitbox_x = hitbox_shape.position.x
		original_position_saved = true


	# Mirror the hitbox around the AnimatedSprite2D
	if animation.flip_h:

		hitbox_shape.position.x = (animation.position.x * 2) - original_hitbox_x

		print("ATTACKING LEFT")
		print("Hitbox X: ", hitbox_shape.position.x)

	else:

		hitbox_shape.position.x = original_hitbox_x

		print("ATTACKING RIGHT")
		print("Hitbox X: ", hitbox_shape.position.x)


	animation.play("attack 1")
	animation_player.play("attack")


	if player.is_on_floor():
		player.velocity.x = 0


func update(delta):

	if animation.is_playing():
		return


	if Input.is_action_just_pressed("jump"):
		state_machine.changestate(state_machine.jump)


	if Input.is_action_pressed("left") or Input.is_action_pressed("right"):
		state_machine.changestate(state_machine.run)
	else:
		state_machine.changestate(state_machine.idle)			

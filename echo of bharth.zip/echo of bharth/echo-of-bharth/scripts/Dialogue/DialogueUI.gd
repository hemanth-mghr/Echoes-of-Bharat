class_name DialogueUI
extends CanvasLayer

signal choice_selected(choice_index: int)

@onready var panel: Control = $Panel
@onready var speaker_name: Label = $Panel/Margin/VBox/SpeakerName
@onready var dialogue_text: Label = $Panel/Margin/VBox/DialogueText
@onready var choice_1_button: Button = $Panel/Margin/VBox/Choices/Choice1Button
@onready var choice_2_button: Button = $Panel/Margin/VBox/Choices/Choice2Button


func _ready() -> void:
	choice_1_button.pressed.connect(_on_choice_1_pressed)
	choice_2_button.pressed.connect(_on_choice_2_pressed)
	panel.hide()


func open_dialogue(speaker: String, line: String, choices: Array[String]) -> void:
	speaker_name.text = speaker
	dialogue_text.text = line
	choice_1_button.text = choices[0]
	choice_2_button.text = choices[1]
	panel.show()


func close_dialogue() -> void:
	panel.hide()


func _on_choice_1_pressed() -> void:
	choice_selected.emit(0)


func _on_choice_2_pressed() -> void:
	choice_selected.emit(1)

class_name StateMachine
extends Node


var currentstate


@onready var idle = $Idle
@onready var run = $Run
@onready var jump = $Jump
@onready var attack = $Attack


func _ready() -> void:

	var player = get_parent()

	var animation = player.get_node("AnimatedSprite2D")
	var animation_player = player.get_node("AnimationPlayer")
	var attack_box = player.get_node("attackbox")


	# Give every state the StateMachine

	idle.state_machine = self
	run.state_machine = self
	jump.state_machine = self
	attack.state_machine = self


	# Give every state the Player

	idle.player = player
	run.player = player
	jump.player = player
	attack.player = player


	# Give every state the AnimatedSprite2D

	idle.animation = animation
	run.animation = animation
	jump.animation = animation
	attack.animation = animation


	# Give Attack state the AnimationPlayer

	attack.animation_player = animation_player


	# Give Attack state the AttackBox

	attack.attack_box = attack_box


	# Start with Idle

	currentstate = idle

	currentstate.enter()


func _physics_process(delta: float) -> void:

	currentstate.update(delta)


func changestate(newstate):

	currentstate.exit()

	currentstate = newstate

	currentstate.enter()

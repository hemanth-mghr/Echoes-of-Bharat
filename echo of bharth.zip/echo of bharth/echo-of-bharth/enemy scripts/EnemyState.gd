class_name EnemyState
extends Node


# The enemy that owns this state.
var enemy: Enemy


# The StateMachine that controls this state.
var state: EnemyStateMachine


# Called when entering the state.
func enter() -> void:
	pass


# Called every frame while this state is active.
func update(delta: float) -> void:
	pass


# Called when leaving the state.
func exit() -> void:
	pass

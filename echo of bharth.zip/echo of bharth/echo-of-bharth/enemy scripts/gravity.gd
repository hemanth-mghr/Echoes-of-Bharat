extends Node

@export var charecterbody2d : CharacterBody2D

const gravity=2000


func _physics_process(delta: float) -> void:
	
	
	if not charecterbody2d.is_on_floor():
		charecterbody2d.velocity.y+=gravity*delta
	charecterbody2d.move_and_slide()		
	
	
	
	



# Called when the node enters the scene tree for the first time.

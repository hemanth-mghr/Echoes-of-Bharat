class_name EnemyStateMachine
extends Node


# ============================================================
# STATES
# ============================================================

@onready var idle: EnemyState = $Idle
@onready var chase: EnemyState = $Chase
@onready var attack: EnemyState = $Attack


# Current active state.
var current_state: EnemyState


# ============================================================
# READY
# ============================================================

func _ready() -> void:

	# Give every state a reference to this StateMachine
	# and to the Enemy.

	for child in get_children():

		if child is EnemyState:
			child.state = self
			child.enemy = get_parent()


	# Start with Idle.
	current_state = idle
	current_state.enter()


# ============================================================
# UPDATE
# ============================================================

func _process(delta: float) -> void:

	if current_state:
		current_state.update(delta)


# ============================================================
# CHANGE STATE
# ============================================================

func change_state(new_state: EnemyState) -> void:

	# Leave old state.
	if current_state:
		current_state.exit()


	# Change current state.
	current_state = new_state


	# Enter new state.
	current_state.enter()

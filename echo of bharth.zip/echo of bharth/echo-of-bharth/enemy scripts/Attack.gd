class_name EnemyAttack
extends EnemyState


# ============================================================
# REFERENCES
# ============================================================

# Drag AnimatedSprite2D into this.
@export var animation: AnimatedSprite2D

# Drag AnimationPlayer into this.
@export var animation_player: AnimationPlayer


# ============================================================
# VARIABLES
# ============================================================

var attack_finished: bool = false


# ============================================================
# ENTER
# ============================================================

func enter() -> void:

	print("Enemy entered Attack")

	attack_finished = false


	# Stop enemy.
	enemy.velocity.x = 0


	# Make sure AttackBox is on correct side.
	enemy.update_facing(enemy.facing_direction)


	# Play visual sprite animation.
	animation.play("attack")


	# Play AnimationPlayer timeline.
	animation_player.play("attack")


# ============================================================
# UPDATE
# ============================================================

func update(delta: float) -> void:

	# Enemy cannot move during attack.
	enemy.velocity.x = 0


	# AnimationPlayer told us attack is finished.
	if attack_finished:

		var idle_state := state.idle as EnemyIdle
		idle_state.begin_post_attack_idle()
		state.change_state(idle_state)


# ============================================================
# EXIT
# ============================================================

func exit() -> void:

	enemy.velocity.x = 0


# ============================================================
# ANIMATION PLAYER FINISHED SIGNAL
# ============================================================

func _on_animation_player_animation_finished(
	anim_name: StringName
) -> void:

	if anim_name == "attack":

		attack_finished = true

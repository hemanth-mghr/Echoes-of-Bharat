class_name EnemyIdle
extends EnemyState


# Drag AnimatedSprite2D here in Inspector.
@export var animation: AnimatedSprite2D


# How long enemy waits in Idle after an attack.
@export var idle_after_attack_time: float = 0.55


var idle_timer: float = 0.0


# ============================================================
# ENTER
# ============================================================

func enter() -> void:

	print("Enemy entered Idle")

	enemy.velocity.x = 0

	animation.play("idle")


func begin_post_attack_idle() -> void:
	idle_timer = max(idle_after_attack_time, 0.0)


# ============================================================
# UPDATE
# ============================================================

func update(delta: float) -> void:

	enemy.velocity.x = 0


	# Wait a little after attack.
	if idle_timer > 0:

		idle_timer -= delta
		return


	# No player detected.
	if enemy.player == null:
		return


	# Player is close enough.
	if enemy.player_in_attack_range:

		state.change_state(state.attack)

	# Player detected but too far away.
	else:

		state.change_state(state.chase)


# ============================================================
# EXIT
# ============================================================

func exit() -> void:
	pass

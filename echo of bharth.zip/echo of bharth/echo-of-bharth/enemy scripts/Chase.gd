class_name EnemyChase
extends EnemyState


# Drag AnimatedSprite2D here.
@export var animation: AnimatedSprite2D


# ============================================================
# ENTER
# ============================================================

func enter() -> void:

	print("Enemy entered Chase")

	animation.play("run")


# ============================================================
# UPDATE
# ============================================================

func update(delta: float) -> void:

	# --------------------------------------------------------
	# Player disappeared
	# --------------------------------------------------------

	if enemy.player == null:

		enemy.velocity.x = 0

		state.change_state(state.idle)

		return

	# --------------------------------------------------------
	# Player is close enough to attack
	# --------------------------------------------------------

	var player_body: CollisionShape2D = enemy.player.get_node("CollisionShape2D")
	var to_player: Vector2 = player_body.global_position - enemy.body_shape.global_position
	if enemy.player_in_attack_range or (absf(to_player.x) <= enemy.attack_distance and absf(to_player.y) <= 28.0):

		enemy.velocity.x = 0
		enemy.update_facing(signf(to_player.x))

		state.change_state(state.attack)

		return


	# --------------------------------------------------------
	# Move toward player
	# --------------------------------------------------------

	var direction: float = signf(to_player.x)
	if direction == 0.0:
		enemy.velocity.x = 0
		return
	enemy.velocity.x = direction * enemy.move_speed

	# Face player.
	enemy.update_facing(direction)


# ============================================================
# EXIT
# ============================================================

func exit() -> void:

	enemy.velocity.x = 0

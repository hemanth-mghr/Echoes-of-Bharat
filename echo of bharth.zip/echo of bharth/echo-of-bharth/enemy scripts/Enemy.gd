class_name Enemy
extends CharacterBody2D


# ============================================================
# MOVEMENT
# ============================================================

@export var move_speed: float = 80.0
@export var attack_distance: float = 20.0
@export var max_health: int = 100
@export var attack_damage: int = 30
@export_range(1.0, 5.0, 0.1) var strengthened_health_multiplier: float = 1.5
@export_range(1.0, 5.0, 0.1) var strengthened_damage_multiplier: float = 1.5
@export_range(1.0, 3.0, 0.05) var strengthened_speed_multiplier: float = 1.25

var health: int = 100
var is_strengthened: bool = false
var invulnerable: bool = false
var blink_time: float = 0.0
var blink_interval: float = 0.0
var blink_visible: bool = true
var is_dead: bool = false


# ============================================================
# ATTACK POSITION
# ============================================================

# How far in front of the enemy the attack areas should be.
#@export var attack_offset: float = 30.0


# ============================================================
# REFERENCES
# ============================================================

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var attack_box: Area2D = $FacingPivot/AttackBox
@onready var attack_range: Area2D = $FacingPivot/AttackRange
@onready var facing_pivot: Node2D = $FacingPivot
@onready var body_shape: CollisionShape2D = $CollisionShape2D


func _ready() -> void:
	health = max_health
	add_to_group("enemy")


func take_damage(amount: int = 20) -> void:
	if invulnerable or is_dead:
		return
	health = maxi(health - amount, 0)
	if health == 0:
		die()
	else:
		start_hit_blink()


func strengthen() -> void:
	if is_strengthened or is_dead:
		return
	is_strengthened = true
	max_health = roundi(max_health * strengthened_health_multiplier)
	health = max_health
	attack_damage = roundi(attack_damage * strengthened_damage_multiplier)
	move_speed *= strengthened_speed_multiplier


func die() -> void:
	is_dead = true
	invulnerable = false
	velocity = Vector2.ZERO
	set_collision_layer_value(1, false)
	set_collision_mask_value(1, false)
	$CollisionShape2D.set_deferred("disabled", true)
	$DetectionArea.set_deferred("monitoring", false)
	attack_box.set_deferred("monitoring", false)
	attack_range.set_deferred("monitoring", false)
	$StateMachine.set_process(false)
	$Gravity.set_physics_process(false)
	sprite.play("death")
	get_tree().create_timer(1.6).timeout.connect(func(): queue_free())


func start_hit_blink() -> void:
	invulnerable = true
	blink_time = 0.45
	blink_interval = 0.0
	blink_visible = true


func _process(delta: float) -> void:
	if not invulnerable or is_dead:
		return
	blink_time -= delta
	blink_interval -= delta
	if blink_interval <= 0.0:
		blink_visible = not blink_visible
		sprite.visible = blink_visible
		blink_interval = 0.07
	if blink_time <= 0.0:
		invulnerable = false
		sprite.visible = true

# The player currently detected by the enemy.
var player: CharacterBody2D = null

# True when the player's body overlaps AttackRange.
var player_in_attack_range: bool = false


# ============================================================
# FACING
# ============================================================

# 1 = facing right
# -1 = facing left
var facing_direction: int = -1


# ============================================================
# DETECTION AREA
# ============================================================

func _on_detection_area_body_entered(body: Node2D) -> void:

	if body.is_in_group("player"):
		player = body


func _on_detection_area_body_exited(body: Node2D) -> void:

	if body.is_in_group("player") and body == player:
		player = null
		player_in_attack_range = false


# ============================================================
# ATTACK RANGE
# ============================================================

func _on_attack_range_body_entered(body: Node2D) -> void:

	if body.is_in_group("player"):
		player_in_attack_range = true


func _on_attack_range_body_exited(body: Node2D) -> void:

	if body.is_in_group("player"):
		player_in_attack_range = false


func _on_attack_box_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") and body.has_method("take_damage"):
		body.take_damage(attack_damage)


# ============================================================
# FACE LEFT / RIGHT
# ============================================================

#@export var attack_box_offset: float = 30.0
#@export var attack_range_offset: float = 60.0


func update_facing(direction: float) -> void:
	if direction > 0:
		facing_direction = 1
	elif direction < 0:
		facing_direction = -1
	else:
		return

	# The canine spritesheet faces left by default, so right-facing uses flip_h.
	sprite.flip_h = facing_direction == 1

	facing_pivot.scale.x = -facing_direction

	
